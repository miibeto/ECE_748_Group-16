#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RTL="$ROOT/project_benches/lc3/rtl/verilog"
OUT="$ROOT/project_benches/lc3/sim/regression_results/stage69_$(date +%Y%m%d_%H%M%S)_$$"
BUNDLE="$ROOT/Stage69_Results_Bundle.zip"
mkdir -p "$OUT"
cd "$OUT"
step=initialization
printf 'STAGE69: independent full LC3 public-port reproduction\n' > stage69_summary.txt
finish() {
  local rc=$?
  trap - EXIT
  set +e
  printf 'RUNNER_EXIT=%s LAST_STEP=%s\n' "$rc" "$step" | tee -a stage69_summary.txt
  if (( rc != 0 )); then
    for f in mapping.log build.log; do
      if [[ -f "$f" ]]; then echo "===== $f (tail) ====="; tail -60 "$f"; fi
    done
  fi
  rm -f "$BUNDLE"
  if command -v zip >/dev/null; then
    shopt -s nullglob
    files=(stage69_summary.txt *.log)
    if zip -q -j "$BUNDLE" "${files[@]}"; then
      echo "STAGE69_BUNDLE=$BUNDLE"
    else
      echo "ERROR: could not create ZIP; logs remain in $OUT" >&2
    fi
  else
    echo "ERROR: zip not installed; logs remain in $OUT" >&2
  fi
  exit "$rc"
}
trap finish EXIT
step=tool_check
for tool in vlib vlog vsim timeout zip; do
  command -v "$tool" >/dev/null || { echo "missing $tool; run ml questa" | tee -a stage69_summary.txt >&2; exit 2; }
done
step=source_check
rtl_files=(data_defs.v Fetch.v Decode_Pipelined.v Execute.v Mem_Access.v WriteBack.v Controller_Pipeline.v TopLevelLC3.v)
for f in "${rtl_files[@]}"; do [[ -r "$RTL/$f" ]] || { echo "missing RTL: $RTL/$f" | tee -a stage69_summary.txt; exit 2; }; done
[[ -r "$ROOT/stage69_public_port_tb.sv" ]] || { echo 'missing stage69_public_port_tb.sv' | tee -a stage69_summary.txt; exit 2; }
step=library_setup
echo '===== STAGE69 LIBRARY SETUP ====='
#explicit local library mapping avoids copying or modifying the site ini with vmap -c
SITE_INI="${MODELSIM:-}"
if [[ ! -f "$SITE_INI" ]]; then
  SITE_INI=/mnt/apps/public/COE/mg_apps/questa2026.1/questasim/modelsim.ini
fi
{
  printf '[Library]\nwork = %s/work\n' "$OUT"
  if [[ -f "$SITE_INI" ]]; then printf 'others = %s\n' "$SITE_INI"; fi
} > "$OUT/modelsim.ini"
export MODELSIM="$OUT/modelsim.ini"
{
  echo "MODELSIM=$MODELSIM"
  cat "$MODELSIM"
  vlib "$OUT/work"
} > mapping.log 2>&1
step=compile
echo '===== STAGE69 COMPILE ====='
paths=(); for f in "${rtl_files[@]}"; do paths+=("$RTL/$f"); done
vlog -sv -work work -suppress 2223 -suppress 2286 "+incdir+$RTL" "${paths[@]}" "$ROOT/stage69_public_port_tb.sv" > build.log 2>&1
failed=0
for test in straight cf67_taken cf67_not_taken cf67_never cf67_jump cf67_chain; do
  step="simulate_$test"
  echo "===== STAGE69 $test ====="
  rc=0
  timeout 120s vsim -c work.stage69_public_port_tb "+CASE=$test" -do 'onerror {quit -code 2 -f}; run -all; quit -f' > "$test.log" 2>&1 || rc=$?
  if (( rc != 0 )); then failed=1; fi
  printf '%s simulator_exit=%s\n' "$test" "$rc" | tee -a stage69_summary.txt
  if ! grep 'STAGE69_RESULT case=' "$test.log" | tee -a stage69_summary.txt; then
    failed=1
    echo 'RESULT MISSING' | tee -a stage69_summary.txt
    tail -35 "$test.log"
  fi
  grep 'STAGE69_STORE cycle=' "$test.log" | tee -a stage69_summary.txt || true
done
step=complete
exit "$failed"
