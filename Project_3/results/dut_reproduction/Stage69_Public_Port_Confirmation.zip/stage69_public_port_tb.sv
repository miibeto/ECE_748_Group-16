`timescale 1ns/1ps
module stage69_public_port_tb;
  logic clock = 0;
  logic reset = 1;
  wire [15:0] pc, Data_addr, Data_din;
  wire instrmem_rd, Data_rd;
  logic [15:0] Instr_dout = 0, Data_dout = 0;
  logic complete_instr = 0, complete_data = 0;
  string program_name;
  logic [15:0] expected_value, response_pc;
  logic [15:0] saved_addr, saved_data;
  bit saved_write;
  bit data_request_served = 0;
  int cycles = 0, writes = 0, wrong = 0, protocol_errors = 0;
  logic [15:0] final_data = 'x;
  LC3 dut (.clock(clock), .reset(reset), .pc(pc), .instrmem_rd(instrmem_rd),
           .Instr_dout(Instr_dout), .complete_instr(complete_instr),
           .complete_data(complete_data), .Data_addr(Data_addr), .Data_din(Data_din),
           .Data_dout(Data_dout), .Data_rd(Data_rd));
  always #5 clock = ~clock;
  function automatic logic [15:0] instruction_at(input logic [15:0] addr);
    case (addr)
      16'h3000: return 16'h5020;
      16'h3001: return program_name == "cf67_jump" ? 16'hec06 : 16'h5260;
      16'h3002: return 16'h54a0;
      16'h3003: return 16'h56e0;
      16'h3004: begin
        case (program_name)
          "cf67_taken": return 16'h0403;
          "cf67_never": return 16'h0003;
          "cf67_jump": return 16'hc180;
          "straight": return 16'h56e0;
          default: return 16'h0203;
        endcase
      end
      16'h3005: return program_name == "cf67_chain" ? 16'h0402 : 16'h1021;
      16'h3006: return 16'h5920;
      16'h3007: return 16'h5b60;
      16'h3008: return 16'h1022;
      16'h3009: return 16'h5fe0;
      16'h300a: return 16'h5da0;
      16'h300b: return 16'h3014;
      default: return 16'h54a0;
    endcase
  endfunction
  initial begin
    if (!$value$plusargs("CASE=%s", program_name)) $fatal(1,"CASE required");
    case (program_name)
      "cf67_taken", "cf67_jump", "cf67_chain": expected_value = 16'h0002;
      "cf67_not_taken", "cf67_never", "straight": expected_value = 16'h0003;
      default: $fatal(1,"unsupported case %s",program_name);
    endcase
    repeat (20) @(negedge clock);
    //release reset after the falling edge; neither responder samples reset here for a request
    reset <= 0;
    repeat (100) @(negedge clock);
    $display("STAGE69_RESULT case=%s writes=%0d expected=%04h actual=%04h wrong=%0d protocol_errors=%0d pass=%0d",
      program_name,writes,expected_value,final_data,wrong,protocol_errors,
      (writes==1 && wrong==0 && protocol_errors==0 && final_data===expected_value));
    $finish;
  end
  //sample the request at a rising edge; publish the registered word in the nba region
  //the previous word is still available to the dut at this edge
  always @(posedge clock) begin
    if (reset) begin
      Instr_dout <= 0;
      complete_instr <= 0;
      response_pc <= 0;
    end else begin
      cycles = cycles + 1;
      if (cycles<=45)
        $display("STAGE69_EDGE cycle=%0d t=%0t pc=%04h rd=%b ci=%b resp_pc=%04h instr=%04h data_rd=%b cd=%b addr=%04h din=%04h",
          cycles,$time,pc,instrmem_rd,complete_instr,response_pc,Instr_dout,Data_rd,complete_data,Data_addr,Data_din);
      if (instrmem_rd === 1'b1) begin
        if ($isunknown(pc)) begin
          protocol_errors = protocol_errors + 1;
          complete_instr <= 0;
        end else begin
          response_pc <= pc;
          Instr_dout <= instruction_at(pc);
          complete_instr <= 1;
          if (cycles<=45) $display("STAGE69_READ cycle=%0d pc=%04h word=%04h",cycles,pc,instruction_at(pc));
        end
      end else if (complete_instr && ((Data_rd===1'b0)||(Data_rd===1'b1))) begin
        //hold the outstanding instruction during the documented data-memory stall
      end else begin
        complete_instr <= 0;
        //hold the last memory word, but mark it invalid
      end
      //commit a write only at the clock edge where completion is sampled
      if (complete_data) begin
        if (Data_addr !== saved_addr || Data_rd !== !saved_write ||
            (saved_write && Data_din !== saved_data)) begin
          protocol_errors = protocol_errors + 1;
          $display("STAGE69_DATA_PROTOCOL addr=%04h captured=%04h rd=%b expected_rd=%b din=%04h captured_data=%04h",Data_addr,saved_addr,Data_rd,!saved_write,Data_din,saved_data);
        end else if (saved_write) begin
          writes = writes + 1;
          final_data = saved_data;
          if (saved_addr !== 16'h3020 || saved_data !== expected_value) wrong = wrong + 1;
          $display("STAGE69_STORE cycle=%0d addr=%04h value=%04h expected=%04h",cycles,saved_addr,saved_data,expected_value);
        end
      end
    end
  end
  //single-store directed tests: acknowledge once, then wait for bus release
  //this is not a general-purpose back-to-back or indirect memory responder
  always @(negedge clock) begin
    if (reset) begin
      complete_data <= 0;
      Data_dout <= 0;
      data_request_served <= 0;
    end else if (complete_data) begin
      complete_data <= 0;
      Data_dout <= 0;
    end else if (Data_rd === 1'bz) begin
      //rearm only once the completed transaction has left the public bus
      if (data_request_served)
        $display("STAGE69_DATA_RELEASE t=%0t", $time);
      data_request_served <= 0;
    end else if (!data_request_served && (Data_rd===1'b0 || Data_rd===1'b1)) begin
      if ($isunknown(Data_addr) || (Data_rd===1'b0 && $isunknown(Data_din))) begin
        $display("STAGE69_UNKNOWN_DATA_REQUEST addr=%04h din=%04h rd=%b",Data_addr,Data_din,Data_rd);
      end else begin
        saved_addr <= Data_addr;
        saved_data <= Data_din;
        saved_write <= Data_rd===1'b0;
        Data_dout <= 0;
        complete_data <= 1;
        data_request_served <= 1;
        $display("STAGE69_DATA_ARM t=%0t addr=%04h rd=%b din=%04h",$time,Data_addr,Data_rd,Data_din);
      end
    end
  end
endmodule
